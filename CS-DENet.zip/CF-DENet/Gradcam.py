import torch
from PIL import Image
import matplotlib.pyplot as plt
from torchvision import models
from torchvision import transforms
from datetime import datetime
import cv2
import matplotlib.pyplot as plt
import torch.nn as nn
import os
import yaml
import argparse
import random
import numpy as np
from configs.default import strategy_cfg
from configs.default import dataset_cfg
from models.baseline import Baseline
parser = argparse.ArgumentParser()
parser.add_argument("--cfg", type=str, default="configs/SYSU.yml")
    ################
parser.add_argument('--gpu', default='0', type=str,
                    help='gpu device ids for CUDA_VISIBLE_DEVICES')
####################
args = parser.parse_args()

######################
os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu
device = 'cuda' if torch.cuda.is_available() else 'cpu'
################

# set random seed
seed = 0
random.seed(seed)
np.random.RandomState(seed)
np.random.seed(seed)
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)

# enable cudnn backend
torch.backends.cudnn.benchmark = True
# torch.backends.cudnn.benchmark = False
# torch.backends.cudnn.deterministic = True

# load configuration
customized_cfg = yaml.load(open(args.cfg, "r"), Loader=yaml.SafeLoader)

cfg = strategy_cfg
cfg.merge_from_file(args.cfg)

dataset_cfg = dataset_cfg.get(cfg.dataset)

for k, v in dataset_cfg.items():
    cfg[k] = v

if cfg.sample_method == 'identity_uniform' or 'identity_random': #'identity_uniform' or 'identity_random'
    cfg.batch_size = cfg.p_size * cfg.k_size

cfg.freeze()

model = Baseline(num_classes=cfg.num_id,
                 pattern_attention=cfg.pattern_attention,
                 modality_attention=cfg.modality_attention,
                 mutual_learning=cfg.mutual_learning,
                 decompose=cfg.decompose,
                 drop_last_stride=cfg.drop_last_stride,
                 triplet=cfg.triplet,
                 k_size=cfg.k_size,
                 center_cluster=cfg.center_cluster,
                 center=cfg.center,
                 margin=cfg.margin,
                 num_parts=cfg.num_parts,
                 weight_KL=cfg.weight_KL,
                 weight_sid=cfg.weight_sid,
                 weight_sep=cfg.weight_sep,
                 update_rate=cfg.update_rate,
                 classification=cfg.classification,
                 bg_kl=cfg.bg_kl,
                 sm_kl=cfg.sm_kl,
                 fb_dt=cfg.fb_dt,
                 IP=cfg.IP,
                 distalign=cfg.distalign)

model_dir= "E:\yl\YL_SSSOF_e\checkpoints\sysu\SYSU_v1\model_best.pth"
# model_dir= "../log/market1501/model_20240717045612.pth.tar"


checkpoint = torch.load(model_dir)
model.load_state_dict(checkpoint)

transform = transforms.Compose([
    transforms.Resize((384, 144)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])
# model_features=nn.Sequential(*list(model.children())[:-2])
# print(model_features)
input_folder="E:/dataset/SYSU-MM01/cam1/0001"
output_folder="C:/Users/reid/Desktop/heatmap/visible"

# input_folder="input_infpic"
# output_folder="out_infpic"

weight=[0.9,0.9,1.1]
current_datetime=datetime.now()
output_folder=output_folder+'/'+current_datetime.strftime("%Y-%m-%d-%H;%M")
model.eval()
os.makedirs(output_folder,exist_ok=True)
soft_max = nn.Softmax()
sigmoid = nn.Sigmoid()

def Batch_creat_heatmap(model, input_folder, output_folder, filename, weight, feature_lay_need):
    blue_weight=weight[0]
    green_wight=weight[1]
    red_wight=weight[2]
    image_path = input_folder + '/' + filename
    output_path = output_folder + '/' + filename


    image = Image.open(image_path)
    image=image.convert("RGB")
    input_tensor = transform(image).unsqueeze(0)

    with torch.no_grad():
        # feature,  feature_attentionWeight,yl4 = model(input_tensor)
        attention_map,attention = model(input_tensor)
    #feature = feature.unsqueeze(0)
    #logits = logits.unsqueeze(0)
    #fc_weight = soft_max(fc_weight)
    feature_lay=feature_lay_need
    attention_map=attention_map[feature_lay]
    attention = attention[feature_lay]
    #attention = attention.squeeze(0)
    attention_map = attention_map.squeeze(0)  # 去掉批次维度
    #attention_map = torch.mean(attention_map, dim=0)  # 计算每个通道的平均值作为注意力热图
    c,h,w = attention_map.size()
    cam = torch.matmul(attention,attention_map.reshape(c,h*w))
    cam = cam.reshape(h,w).detach().numpy()
    #feature_lay = feature_lay_need
    #attention_map = feature[feature_lay]
    #attention_map = attention_map.squeeze(0)  # 去掉批次维度

    #feature_attentionWeight_list=feature_attentionWeight[feature_lay]
    #feature_AW_MAX_index=torch.argmax(feature_attentionWeight_list)
    #attention_map_channel=attention_map[feature_AW_MAX_index.item(),:,:]
    #attention_map=attention_map_channel

    #heatmap_np = attention_map.detach().numpy()
    cam_img = (cam - cam.min()) / (cam.max() - cam.min())  # Normalize
    cam_img = np.uint8(255 * cam_img)

    heatmap_color = cv2.applyColorMap(cam_img, cv2.COLORMAP_JET)
    heatmap_color = cv2.resize(heatmap_color, image.size)

    image_bgr = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)  # 将 PIL 图像转换为 numpy 数组并转换颜色通道顺序
    overlayed_image = cv2.addWeighted(image_bgr, 0.6, heatmap_color, 0.5, 0)

    overlayed_image = overlayed_image.astype(np.float64)
    overlayed_image[:,:,0]*=blue_weight
    overlayed_image[:,:,1]*=green_wight
    overlayed_image[:,:,2]*=red_wight

    cv2.imwrite(output_path, overlayed_image)
    print("图像{}热力图已生成并保存,热力通道参数为红色通道{}，绿色通道{}，蓝色通道{}".format(filename,red_wight,green_wight,blue_weight))

count=0
feature_lay_need=2

for file_name in os.listdir(input_folder):
    Batch_creat_heatmap(model, input_folder, output_folder, file_name,weight,feature_lay_need )
    count+=1

print("*"*50+"\n文件夹中共有{}个文件，成功生成并保存了{}个注意力热图,保存在{}".format(len(os.listdir(input_folder)),count,output_folder))

