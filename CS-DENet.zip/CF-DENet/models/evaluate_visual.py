
from __future__ import print_function, division
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import torch

matplotlib.use('agg')
import time
import os
import math
import seaborn as sns

def evaluate_visual( q_feats,g_feats , q_pids, g_pids, q_camids, g_camids, save_path):
    distmat = np.matmul(q_feats, np.transpose(g_feats))/(np.matmul(torch.norm(q_feats,dim=1,p=2),np.transpose(torch.norm(g_feats,dim=1,p=2))))
    num_q, num_g = distmat.shape
    inter_class_List = []
    intra_class_List = []

    for i in range(num_q):
        # get query pid and camid
        q_pid = q_pids[i]
        q_camid = q_camids[i]
        feat_list = distmat[i,:]

        id_same = (g_pids == q_pid) + 0
        cam_same = (g_camids == q_camid) + 0
        id_diff = 1 - (id_same)
        cam_diff = 1 - (cam_same)

        # diff CAM & diff ID
        inter_class_feat = feat_list * cam_diff * id_diff
        remove = 1 - ((inter_class_feat == 0)+0)
        inter_class_feat = list(inter_class_feat[np.where(remove == 1)])
        inter_class_List.extend(inter_class_feat)

        # diff CAM & same ID
        intra_class_feat = feat_list * cam_diff * id_same
        remove = 1 - ((intra_class_feat == 0)+0)
        intra_class_feat = intra_class_feat[np.where(remove == 1)]
        intra_class_List.extend(intra_class_feat)

    #if opt.test_hist_all:
    #flag1 = [False, True, True]
    #flag2 = [False, False, True]

    #for k in range(3):

    intra_class_List_tmp = intra_class_List.copy()
    inter_class_List_tmp = inter_class_List.copy()

        #if flag1[k]:  # cos-sim to dist
    for j in range(len(intra_class_List)):
        #if intra_class_List_tmp[j]<1:
        intra_class_List_tmp[j] = math.acos(intra_class_List_tmp[j])

    for j in range(len(inter_class_List)):
        #if inter_class_List_tmp[j]<1:
        inter_class_List_tmp[j] = math.acos(inter_class_List_tmp[j])

    fig = plt.figure(figsize=(6, 6), dpi=200)
    ax = fig.add_subplot(111)

    sns.distplot(inter_class_List_tmp, bins=100, hist=True, norm_hist=True, kde=False, ax=ax, color='g', label='Inter-class')
    sns.distplot(intra_class_List_tmp, bins=100, hist=True, norm_hist=True, kde=False, ax=ax, color='r', label='Intra-class')

    ax.set_xlabel('Feature distance')
    #else:
        #ax.set_xlabel('Feature similarity')
    ax.set_ylabel('Frequency')
    plt.legend(loc='upper left')
    # plt.show()
    fig.savefig(save_path[:-4] + '_'  + save_path[-4:])
    plt.close('all')

'''
    else:

        if opt.test_hist_dist:  # cos-sim to dist
            for j in range(len(intra_class_List)):
                intra_class_List[j] = math.acos(intra_class_List[j])

            for j in range(len(inter_class_List)):
                inter_class_List[j] = math.acos(inter_class_List[j])

        fig = plt.figure(figsize=(6, 6), dpi=200)
        ax = fig.add_subplot(111)
        if opt.test_hist_grid:
            plt.xlim(opt.test_hist_grid_min, opt.test_hist_grid_max)

        sns.distplot(inter_class_List, bins=100, hist=True, norm_hist=True, kde=False, ax=ax, color='g', label='Inter-class')
        sns.distplot(intra_class_List, bins=100, hist=True, norm_hist=True, kde=False, ax=ax, color='r', label='Intra-class')
        if opt.test_hist_dist:
            ax.set_xlabel('Feature distance')
        else:
            ax.set_xlabel('Feature similarity')
        ax.set_ylabel('Frequency')
        plt.legend(loc='upper left')
        # plt.show()
        fig.savefig(save_path)
        plt.close('all')
'''