import torch
from torch import nn
from torch.nn import functional as F
class Discrimination(nn.Module):
    def __init__(self, dim=2048):
        super(Discrimination, self).__init__()
        self.fc1 = nn.Linear(dim, 100)
        self.bn1 = nn.BatchNorm1d(100)
        self.fc2 = nn.Linear(100, 100)
        self.bn2 = nn.BatchNorm1d(100)
        self.fc3 = nn.Linear(100, 2)

    def forward(self, x):
        x = F.dropout(F.relu(self.bn1(self.fc1(x))), training=self.training)
        x = F.dropout(F.relu(self.bn2(self.fc2(x))), training=self.training)
        x = self.fc3(x)
        return x

discriminator = Discrimination(2048)
classifier_sp = nn.Linear(2048, 751, bias=False)
#print(torch.norm(classifier_sp.weight.permute(1,0)))
weight1 = classifier_sp.weight.permute(1,0).detach()
weight2 = discriminator.fc1.weight.permute(1,0).detach()
w1 = torch.norm(torch.flatten(weight1,start_dim = 1), dim = 1)
w2 = torch.norm(torch.flatten(weight2,start_dim = 1), dim = 1)
print(w1.size(),w2.size())