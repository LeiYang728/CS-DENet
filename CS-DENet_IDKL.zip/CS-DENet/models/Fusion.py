import torch.nn as nn
import torch
import math
from torch.nn import functional as F

class Fusion(nn.Module):
    def __init__(self):
        super(Fusion, self).__init__()
        self.sigmoid = nn.Sigmoid()

    def forward(self, x, bn,weight_earase):#x[s,c]
        x_0 = x[0]
        weight_select = torch.zeros_like(weight_earase)
        threshold = 0.05
        weight_select += weight_earase >= threshold + 0
        x_1 = x[1] * weight_select
        p = 1e+6
        bn1, bn2 = bn[0].weight.abs(), bn[1].weight.abs()  # c 2048
        bn1 = (bn1 / bn1.sum())
        bn2 = (bn2 / bn2.sum())
        bn1 = torch.round(bn1*p)
        bn2 = torch.round(bn2*p)
        x_0[:,bn2 >= bn1] += (1-self.sigmoid(x_0[:,bn2>=bn1]))*x_1[:,bn2 >= bn1]
        out = x_0
        return out

class Fusion_1(nn.Module):
    def __init__(self):
        super(Fusion_1, self).__init__()
        self.sigmoid = nn.Sigmoid()

    def forward(self, x, bn,weight,weight_conv):#x[s,c]
        x_0 = x[0]
        b,c,_,_ = x_0.size()
        x_1 = x[1]*weight.view(b,c,1,1)
        p = 1e+6
        bn1, bn2 = bn[0].weight.abs(), bn[1].weight.abs()  # c 2048
        bn1 = (bn1 / bn1.sum())
        bn2 = (bn2 / bn2.sum())
        bn1 = torch.round(bn1*p)
        bn2 = torch.round(bn2*p)
        x_0[:,bn2 >= bn1] += (1-self.sigmoid(x_0[:,bn2>=bn1]))*x_1[:,bn2 >= bn1]
        out = x_0
        return out


