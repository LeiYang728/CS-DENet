import torch
import torch.nn as nn
from torch.nn import functional as F



class S1Layer(nn.Module):
    def __init__(self, channel, reduction=16):
        super(S1Layer, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.inchannel = channel
        self.conv1 = nn.Conv2d(self.inchannel, self.inchannel // reduction, kernel_size= 1, bias=False)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(self.inchannel//reduction,self.inchannel,kernel_size=1,bias=False)
        self.bn1 = nn.BatchNorm2d(self.inchannel)
        self.sigmoid = nn.Sigmoid()
        self.list = []
    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x)
        y = self.conv1(y)
        y = self.relu(y)
        y = self.conv2(y)
        y = self.bn1(y)
        y = self.sigmoid(y)
        return  y

class S2Layer(nn.Module):
    def __init__(self,channel,reduction=16):
        super(S2Layer,self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.inchannel = channel
        self.conv1 = nn.Conv2d(self.inchannel, self.inchannel // reduction, kernel_size= 1, bias=False)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(self.inchannel//reduction,self.inchannel,kernel_size=1,bias=False)
        self.bn1 = nn.BatchNorm2d(self.inchannel)
        self.sigmoid = nn.Sigmoid()
    def forward(self,x):
        b,c,_,_ = x.size()
        y = self.avg_pool(x)
        y = self.conv1(y)
        y = self.relu(y)
        y = self.conv2(y)
        y = self.bn1(y)
        y = self.sigmoid(y)
        return y

class Feature_activation(nn.Module):
    def __init__(self, in_channels ):
        super(Feature_activation,self).__init__()
        self.inchannels = in_channels
        self.s1layer = S1Layer(channel = self.inchannels)
        self.s2layer = S2Layer(channel = self.inchannels)

    def forward(self,x):
        b,c,_,_ = x.size()
        y1  = self.s1layer(x)
        out_origin = x * y1.expand_as(x)
        feature_activation = out_origin
        y2 = self.s2layer(feature_activation)
        out_activation = feature_activation*y2.expand_as(feature_activation)
        return out_origin,out_activation

