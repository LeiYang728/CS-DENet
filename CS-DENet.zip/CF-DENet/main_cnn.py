import torch
from PIL import Image
import matplotlib.pyplot as plt
from torchvision import models
from torchvision import transforms
from utils_cam import GradCAM, show_cam_on_image, center_crop_img

import matplotlib.pyplot as plt
import os
import yaml
import argparse
import random
import numpy as np
from configs.default import strategy_cfg
from configs.default import dataset_cfg
from models.baseline import Baseline

parser = argparse.ArgumentParser()
parser.add_argument("--cfg", type=str, default="configs/SYSU.yml")
################
parser.add_argument('--gpu', default='0', type=str,
                    help='gpu device ids for CUDA_VISIBLE_DEVICES')
####################
args = parser.parse_args()

######################
os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu
device = 'cuda' if torch.cuda.is_available() else 'cpu'
################

# set random seed
seed = 0
random.seed(seed)
np.random.RandomState(seed)
np.random.seed(seed)
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)

# enable cudnn backend
torch.backends.cudnn.benchmark = True
# torch.backends.cudnn.benchmark = False
# torch.backends.cudnn.deterministic = True

# load configuration
customized_cfg = yaml.load(open(args.cfg, "r"), Loader=yaml.SafeLoader)

cfg = strategy_cfg
cfg.merge_from_file(args.cfg)

dataset_cfg = dataset_cfg.get(cfg.dataset)

for k, v in dataset_cfg.items():
    cfg[k] = v

if cfg.sample_method == 'identity_uniform' or 'identity_random':  # 'identity_uniform' or 'identity_random'
    cfg.batch_size = cfg.p_size * cfg.k_size

cfg.freeze()


def main():
    model = Baseline(num_classes=cfg.num_id,
                     pattern_attention=cfg.pattern_attention,
                     modality_attention=cfg.modality_attention,
                     mutual_learning=cfg.mutual_learning,
                     decompose=cfg.decompose,
                     drop_last_stride=cfg.drop_last_stride,
                     triplet=cfg.triplet,
                     k_size=cfg.k_size,
                     center_cluster=cfg.center_cluster,
                     center=cfg.center,
                     margin=cfg.margin,
                     num_parts=cfg.num_parts,
                     weight_KL=cfg.weight_KL,
                     weight_sid=cfg.weight_sid,
                     weight_sep=cfg.weight_sep,
                     update_rate=cfg.update_rate,
                     classification=cfg.classification,
                     bg_kl=cfg.bg_kl,
                     sm_kl=cfg.sm_kl,
                     fb_dt=cfg.fb_dt,
                     IP=cfg.IP,
                     distalign=cfg.distalign)

    model_dir = "E:\yl\YL_SSSOF_e\checkpoints\sysu\SYSU_v1\model_best.pth"
    # model_dir= "../log/market1501/model_20240717045612.pth.tar"

    if os.path.exists(model_dir):
        checkpoint = torch.load(model_dir)
        model.load_state_dict(checkpoint)
        # model = models.mobilenet_v3_large(pretrained=True)
        target_layers = [model.backbone.shared_module_bh.model_sh_bh.layer4,
                         model.backbone.decouple.decouple_module.layer4, model.backbone.fusion.sigmoid]

    # model = models.vgg16(pretrained=True)
    # target_layers = [model.features]

    # model = models.resnet34(pretrained=True)
    # target_layers = [model.layer4]

    # model = models.regnet_y_800mf(pretrained=True)
    # target_layers = [model.trunk_output]

    # model = models.efficientnet_b0(pretrained=True)
    # target_layers = [model.features]

    data_transform = transforms.Compose([transforms.ToTensor(),
                                         transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])
    # load image
    img_path = "C:\Users\reid\Downloads\0001_removebg_preview_1.jpg"
    assert os.path.exists(img_path), "file: '{}' dose not exist.".format(img_path)
    img = Image.open(img_path).convert('RGB')
    img = np.array(img, dtype=np.uint8)
    # img = center_crop_img(img, 224)

    # [C, H, W]
    img_tensor = data_transform(img)
    # expand batch dimension
    # [C, H, W] -> [N, C, H, W]
    input_tensor = torch.unsqueeze(img_tensor, dim=0)

    cam = GradCAM(model=model, target_layers=target_layers, use_cuda=False)
    target_category = 235  # tabby, tabby cat
    # target_category = 254  # pug, pug-dog

    grayscale_cam = cam(input_tensor=input_tensor, target_category=target_category)

    grayscale_cam = grayscale_cam[0, :]
    visualization = show_cam_on_image(img.astype(dtype=np.float32) / 255.,
                                      grayscale_cam,
                                      use_rgb=True)
    plt.imshow(visualization)
    plt.show()


if __name__ == '__main__':
    main()
