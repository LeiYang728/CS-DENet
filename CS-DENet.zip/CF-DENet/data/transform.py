
import math
import numbers
import random
import numpy as np
from PIL import Image

import torch
import torch.nn as nn


class WeightedGrayscale(nn.Module):
    def __init__(self, weights=None, p=1.0):
        super().__init__()
        self.weights = weights
        self.p = p

    def forward(self, img):
        if self.p < torch.rand(1):
            return img

        if self.weights is not None:
            w1, w2, w3 = self.weights
        else:
            w1 = random.uniform(0, 1)
            w2 = random.uniform(0, 1)
            w3 = random.uniform(0, 1)
            s = w1 + w2 + w3
            w1, w2, w3 = w1 / s, w2 / s, w3 / s
        img_data = np.asarray(img)
        img_data = w1 * img_data[:, :, 0] + w2 * img_data[:, :, 1] + w3 * img_data[:, :, 2]
        img_data = np.expand_dims(img_data, axis=-1).repeat(3, axis=-1)

        return Image.fromarray(np.uint8(img_data))


class ChannelCutMix(nn.Module):

    def __init__(self, p=0.5, scale=(0.02, 0.33), ratio=(0.3, 3.3)):
        super().__init__()
        self.p = p
        self.scale = scale
        self.ratio = ratio

    def forward(self, img):
        if self.p < torch.rand(1):
            return img

        img_h, img_w = img.size  # PIL Image Type
        area = img_h * img_w
        log_ratio = torch.log(torch.tensor(self.ratio))
        i, j, h, w = None, None, None, None
        for _ in range(10):
            cutmix_area = area * torch.empty(1).uniform_(self.scale[0], self.scale[1]).item()
            aspect_ratio = torch.exp(torch.empty(1).uniform_(log_ratio[0], log_ratio[1])).item()
            h = int(round(math.sqrt(cutmix_area * aspect_ratio)))
            w = int(round(math.sqrt(cutmix_area / aspect_ratio)))
            if not (h < img_h and w < img_w):
                continue
            i = torch.randint(0, img_h - h + 1, size=(1,)).item()
            j = torch.randint(0, img_w - w + 1, size=(1,)).item()
            break

        img_data = np.array(img)
        bg_c, fg_c = random.sample(range(3), k=2)
        bg_img_data = img_data[:, :, bg_c]
        fg_img_data = img_data[:, :, fg_c]
        bg_img_data[i:i + h, j:j + w] = fg_img_data[i:i + h, j:j + w]
        img_data = np.expand_dims(bg_img_data, axis=-1).repeat(3, axis=-1)

        return Image.fromarray(np.uint8(img_data))


class SpectrumJitter(nn.Module):

    def __init__(self, factor=0.5, p=0.5):
        super().__init__()
        self.factor = self._check_input(factor, 'spectrum')
        self.p = p

    @torch.jit.unused  # Inspired by the implementation of color jitter in standard libraries
    def _check_input(self, value, name, center=1, bound=(0, float('inf')), clip_first_on_zero=True):
        if isinstance(value, numbers.Number):
            if value < 0:
                raise ValueError("If {} is a single number, it must be non negative.".format(name))
            value = [center - float(value), center + float(value)]
            if clip_first_on_zero:
                value[0] = max(value[0], 0.0)
        elif isinstance(value, (tuple, list)) and len(value) == 2:
            if not bound[0] <= value[0] <= value[1] <= bound[1]:
                raise ValueError("{} values should be between {}".format(name, bound))
        else:
            raise TypeError("{} should be a single number or a list/tuple with lenght 2.".format(name))

        if value[0] == value[1] == center:
            value = None
        return value

    def forward(self, img):
        if self.p < torch.rand(1):
            return img

        selected_c = random.randint(0, 2)

        img_data = np.asarray(img)
        img_data = img_data[:, :, selected_c]
        img_data = np.expand_dims(img_data, axis=-1).repeat(3, axis=-1)
        degenerate = Image.fromarray(np.uint8(img_data))

        factor = float(torch.empty(1).uniform_(self.factor[0], self.factor[1]))
        return Image.blend(degenerate, img, factor)


class ChannelAugmentation(nn.Module):
    def __init__(self, mode=None, p=1.0):
        super().__init__()
        assert mode in [None, 'r', 'g', 'b', 'avg', 'rg_avg', 'rb_avg', 'gb_avg', 'rand', 'wg', 'cc', 'sj']
        self.mode = mode
        self.p = p
        if mode in ['r', 'g', 'b', 'avg', 'rg_avg', 'rb_avg', 'gb_avg', 'rand']:
            self.ca = ChannelSelection(mode=mode, p=p)
        elif mode == 'wg':
            self.ca = WeightedGrayscale(p=p)
        elif mode == 'cc':
            self.ca = ChannelCutMix(p=p)
        elif mode == 'sj':
            self.ca = SpectrumJitter(factor=(0.00, 1.00), p=p)
        else:
            self.ca = NoTransform()

    def forward(self, img):
        return self.ca(img)


class ChannelSelection(nn.Module):

    def __init__(self, mode='rand', p=1.0):
        super().__init__()
        assert mode in ['r', 'g', 'b', 'avg', 'rg_avg', 'rb_avg', 'gb_avg', 'rand']
        self.mode = mode
        self.p = p

    def forward(self, img):
        if self.p < torch.rand(1):
            return img

        img_data = np.array(img)
        if 'avg' in self.mode:
            if self.mode == 'avg':
                pass
            elif self.mode == 'rg_avg':
                img_data = np.stack([img_data[:, :, 0], img_data[:, :, 1]])
            elif self.mode == 'rb_avg':
                img_data = np.stack([img_data[:, :, 0], img_data[:, :, 2]])
            elif self.mode == 'gb_avg':
                img_data = np.stack([img_data[:, :, 1], img_data[:, :, 2]])
            img_data = img_data.mean(axis=-1)
        else:
            if self.mode == 'r':
                selected_c = 0
            elif self.mode == 'g':
                selected_c = 1
            elif self.mode == 'b':
                selected_c = 2
            elif self.mode == 'rand':
                selected_c = random.randint(0, 2)
            img_data = img_data[:, :, selected_c]
        img_data = np.expand_dims(img_data, axis=-1).repeat(3, axis=-1)
        return Image.fromarray(np.uint8(img_data))


class NoTransform(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, img):
        return img
