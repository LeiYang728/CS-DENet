import torch
from torch.nn import Softmax
from torch import nn
from torch.nn import functional as F
class OFPenalty(nn.Module):
    def __init__(self, of_beta):
        super(OFPenalty, self).__init__()

        self.beta = of_beta
        self.softmax = Softmax(dim=-1)

    def dominant_eigenvalue(self, A):
        B, N, _ = A.size()
        x = torch.zeros(B, N, 1, device='cuda')
        nn.init.kaiming_normal_(x, nonlinearity="linear")
#        x = torch.randn(B , N , 1 , device='cuda')
        for _ in range(1):
            x = torch.bmm(A, x)
        # x: 'B x N x 1'
        numerator = torch.bmm(
            torch.bmm(A, x).view(B, 1, N),
            x
        ).squeeze()
        denominator = (torch.norm(x.view(B, N), p=2, dim=1) ** 2).squeeze()

        return numerator / denominator

    def get_singular_values(self, A):
        AAT = F.normalize(torch.bmm(A, A.permute(0, 2, 1)),dim=2)  # C*S*S*C=C*C
#        AAT = self.softmax(AAT)
        B, N, _ = AAT.size()
        largest = self.dominant_eigenvalue(AAT)
        I = torch.eye(N, device='cuda').expand(B, N, N)  # noqa
        I = I * largest.view(B, 1, 1).repeat(1, N, N)  # noqa
        tmp = self.dominant_eigenvalue(AAT - I)
        return tmp + largest, largest

    def apply_penalty(self, x):
        #batches, channels,_ ,_= x.size()
        #W = x.view(batches, channels, -1)
        smallest, largest = self.get_singular_values(x)
        singular_penalty = (largest - smallest)* self.beta

        singular_penalty *= 0.01

        return singular_penalty.sum() / (x.size(0) / 32.)  # Quirk: normalize to 32-batch case

    def HPP(self,x,num_parts):
        patterns = list(torch.chunk(x,num_parts,dim=2))
        parts = []
        for i in range(len(patterns)):
            part = patterns[i]
            b,c,_ = part.size()
            #part = part.view(b,c,-1).permute(0,2,1)
            (part.view(b,c,-1).permute(0,2,1).sum(dim=2)/(part.size(2))).view(part.size(0),1,part.size(2))
            parts.append(part)
        return  torch.cat(parts,dim=2)

    def forward(self, reg_feats):
        b,c,_,_ = reg_feats[0].size()
        w0 = reg_feats[0].view(b,c,-1)
        w1 = reg_feats[1].view(b,c,-1)
        #w0 = self.HPP(reg_feats[0],num_parts=10)
        #w1 = self.HPP(reg_feats[1],num_parts=10)
        W = torch.cat((w0,w1),dim=2)
        b,c,n = W.size()
        cos=False
        if cos:
            cos_s = 0
            for i in range(c-1):
                x = W[:, i]
                y = W[:, i+1]
                x_ = torch.norm(x,dim=1,p=2)
                y_ = torch.norm(y,dim=1,p=2)
                cos_s += ((x*y).sum(1)/(x_*y_)).sum()/(b)
        #return sum([self.apply_penalty(x) for x in reg_feats])
        return 2*self.apply_penalty(W)#,cos_s/(c-1)
