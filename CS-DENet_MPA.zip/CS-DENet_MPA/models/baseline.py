import math
import torch
import torch.nn as nn
from torch.nn import init
from torch.nn import functional as F
from torch.nn import Parameter
import numpy as np
from models.Orthogonal_regulization import OFPenalty
import cv2
from models.resnet import embed_net,Discrimination
from models.resnet import resnet50
from utils.calc_acc import calc_acc
from layers.loss.tcl import tcl_Loss
from layers import TripletLoss
from layers import CenterTripletLoss
from layers import CenterLoss
from layers import cbam
from layers import NonLocalBlockND


def Fb_dt(feat, labels):
    feat_dt = feat
    n_ft = feat_dt.size(0)
    dist_f = torch.pow(feat_dt, 2).sum(dim=1, keepdim=True).expand(n_ft, n_ft)
    dist_f = dist_f + dist_f.t()
    dist_f.addmm_(1, -2, feat_dt, feat_dt.t())
    dist_f = dist_f.clamp(min=1e-12).sqrt()
    mask_ft = labels.expand(n_ft, n_ft).eq(labels.expand(n_ft, n_ft).t())
    mask_ft_1 = torch.ones(n_ft, n_ft, dtype=bool)
    for i in range(n_ft):
        mask_ft_1[i, i] = 0
    mask_ft_2 = []
    for i in range(n_ft):

        mask_ft_2.append(mask_ft[i][mask_ft_1[i]])
    mask_ft_2 = torch.stack(mask_ft_2)
    dist_f_2 = []
    for i in range(n_ft):

        dist_f_2.append(dist_f[i][mask_ft_1[i]])
    dist_f_2 = torch.stack(dist_f_2)
    dist_f_2 = F.softmax(-(dist_f_2 - 1), 1)
    cN_ft = (mask_ft_2[0] == True).sum()
    f_d_ap = []
    for i in range(n_ft):

        f_d_ap.append(dist_f_2[i][mask_ft_2[i]])
    f_d_ap = torch.stack(f_d_ap).flatten()
    loss_f_d_ap = []
    xs_ft = 1
    m_ft = f_d_ap.size(0)
    for i in range(m_ft):
        loss_f_d_ap.append(
            -xs_ft * (1 / cN_ft) * torch.log(xs_ft * cN_ft * f_d_ap[i]))
    loss_f_d_ap = torch.stack(loss_f_d_ap).clamp(max=1e+3).sum() / n_ft
    return loss_f_d_ap
class Baseline(nn.Module):
    def __init__(self, num_classes=None, drop_last_stride=False, pattern_attention=False, modality_attention=0, cml=False, **kwargs):
        super(Baseline, self).__init__()

        self.drop_last_stride = drop_last_stride
        self.pattern_attention = pattern_attention
        self.modality_attention = modality_attention
        self.cml = cml
        self.backbone = embed_net(drop_last_stride=drop_last_stride)

        self.base_dim = 2048
        self.dim = 0
        self.part_num = kwargs.get('num_parts', 0)

        if pattern_attention:
            self.base_dim = 2048
            self.dim = 2048
            self.part_num = kwargs.get('num_parts', 6)
            self.spatial_attention = nn.Conv2d(self.base_dim, self.part_num, kernel_size=1, stride=1, padding=0, bias=True)
            torch.nn.init.constant_(self.spatial_attention.bias, 0.0)
            self.activation = nn.Sigmoid()
            self.weight_sep = kwargs.get('weight_sep', 0.1)

        if cml:
            self.visible_classifier = nn.Linear(self.base_dim + self.dim * self.part_num, num_classes, bias=False)
            self.infrared_classifier = nn.Linear(self.base_dim + self.dim * self.part_num, num_classes, bias=False)

            self.visible_classifier_ = nn.Linear(self.base_dim + self.dim * self.part_num, num_classes, bias=False)
            self.visible_classifier_.weight.requires_grad_(False)
            self.visible_classifier_.weight.data = self.visible_classifier.weight.data

            self.infrared_classifier_ = nn.Linear(self.base_dim + self.dim * self.part_num, num_classes, bias=False)
            self.infrared_classifier_.weight.requires_grad_(False)
            self.infrared_classifier_.weight.data = self.infrared_classifier.weight.data

            self.KLDivLoss = nn.KLDivLoss(reduction='batchmean')
            self.weight_sid = kwargs.get('weight_sid', 0.5)
            self.weight_KL = kwargs.get('weight_KL', 2.0)
            self.update_rate = kwargs.get('update_rate', 0.2)
            self.update_rate_ = self.update_rate

        print("output feat length:{}".format(self.base_dim + self.dim * self.part_num))
        self.bn_neck = nn.BatchNorm1d(self.base_dim + self.dim * self.part_num)
        nn.init.constant_(self.bn_neck.bias, 0) 
        self.bn_neck.bias.requires_grad_(False)

        self.bn_neck_sh = nn.BatchNorm1d(self.base_dim  )
        nn.init.constant_(self.bn_neck_sh.bias, 0)
        self.bn_neck_sh.bias.requires_grad_(False)

        self.bn_neck_im = nn.BatchNorm1d(self.base_dim  )
        nn.init.constant_(self.bn_neck_im.bias, 0)
        self.bn_neck_im.bias.requires_grad_(False)

        if kwargs.get('eval', False):
            return
        self.erase = kwargs.get('erase', False)
        self.classification = kwargs.get('classification', False)
        self.triplet = kwargs.get('triplet', False)
        self.center_cluster = kwargs.get('center_cluster', False)
        self.center_loss = kwargs.get('center', False)
        self.margin = kwargs.get('margin', 0.3)
        self.orth_loss = OFPenalty(0.1)
        self.orth = kwargs.get('orth', False)
        self.erase= kwargs.get('erase', False)
        self.mutual_learning =  self.erase= kwargs.get('mutual_learning', False)
        if self.classification:
            self.classifier = nn.Linear(self.base_dim + self.dim * self.part_num , num_classes, bias=False)
            self.classifier_sh = nn.Linear(self.base_dim, num_classes, bias=False)
            self.classifier_im = nn.Linear(self.base_dim, num_classes, bias=False)
        if self.cml or self.classification:
            self.id_loss = nn.CrossEntropyLoss(ignore_index=-1)
        if self.triplet:
            self.triplet_loss = TripletLoss(margin=self.margin)
        if self.center_cluster:
            k_size = kwargs.get('k_size', 8)
            self.center_cluster_loss = CenterTripletLoss(k_size=k_size, margin=self.margin)
        if self.center_loss:
            self.center_loss = CenterLoss(num_classes, self.base_dim + self.dim * self.part_num)
        self.tcl_loss = tcl_Loss()
        self.D_share = Discrimination(2048)
        self.D_sp = Discrimination(2048)
        self.sigmoid_1 = nn.Sigmoid()
        self.sigmoid_2 = nn.Sigmoid()
        self.sigmoid_3 = nn.Sigmoid()

    def forward(self, inputs, labels=None, **kwargs):
        loss_reg = 0
        loss_center = 0
        modality_logits = None
        modality_feat = None

        cam_ids = kwargs.get('cam_ids')
        sub = (cam_ids == 3) + (cam_ids == 6)
        # CNN
        x_fuse ,fuse_pl , x_sh,x_sh_pl,x_im,x_im_pl,weight_sp_id,weight_erase,weight_sh_id = self.backbone(inputs)

        b, c, w, h = x_fuse.shape

        if self.pattern_attention:
            masks = x_fuse
            masks = self.spatial_attention(masks)
            masks = self.activation(masks)

            feats = []
            for i in range(self.part_num):
                mask = masks[:, i:i+1, :, :]
                feat = mask * x_fuse

                feat = F.avg_pool2d(feat, feat.size()[2:])
                feat = feat.view(feat.size(0), -1)

                feats.append(feat)

            global_feat = F.avg_pool2d(x_fuse, x_fuse.size()[2:])
            global_feat = global_feat.view(global_feat.size(0), -1)

            feats.append(global_feat)
            feats = torch.cat(feats, 1)

            if self.training:
                masks = masks.view(b, self.part_num, w*h)
                loss_reg = torch.bmm(masks, masks.permute(0, 2, 1))
                loss_reg = torch.triu(loss_reg, diagonal = 1).sum() / (b * self.part_num * (self.part_num - 1) / 2)

        else:
            feats = F.avg_pool2d(x_fuse, x_fuse.size()[2:])
            feats = feats.view(feats.size(0), -1)

        if not self.training:
            feats = self.bn_neck(feats)
            return feats
        else:
            return self.train_forward(feats, x_sh,x_sh_pl,x_im,x_im_pl,weight_sp_id,weight_erase,weight_sh_id,labels, loss_reg, sub, **kwargs)

    def train_forward(self, feat, x_sh,x_sh_pl,x_im,x_im_pl,weight_sp_id,weight_erase,weight_sh_id, labels, loss_reg, sub, **kwargs):
        epoch = kwargs.get('epoch')
        metric = {}

        if self.pattern_attention and loss_reg != 0 :
            loss = loss_reg.float() * self.weight_sep
            metric.update({'p-reg': loss_reg.data})
        else:
            loss = 0

        orth = True
        if orth:
            feat_orth = [x_sh, x_im]
            orth_loss = self.orth_loss(feat_orth)
            loss += orth_loss
            metric.update({'orth1': orth_loss.data})

        if self.triplet:
            targets = torch.cat((labels[sub==0],labels[sub==0]),0)
            x_spv,x_shv,x_spi,x_shi = x_im_pl[sub == 0],x_sh_pl[sub == 0],x_im_pl[sub == 1],x_sh_pl[sub == 1]
            inputs_v = torch.cat((x_spv,x_shv),dim=0)
            inputs_i = torch.cat((x_spi,x_shi),dim=0)
            loss_tcl = self.tcl_loss(inputs_v,inputs_v,targets) + self.tcl_loss(inputs_i,inputs_i,targets)
            loss+=loss_tcl
            metric.update({'tcl':loss_tcl.data})
        if self.center_loss:
            center_loss = self.center_loss(feat.float(), labels)
            loss += center_loss
            metric.update({'cen': center_loss.data})

        if self.center_cluster:
            center_cluster_loss, _, _ = self.center_cluster_loss(feat.float(), labels)
            loss += center_cluster_loss
            metric.update({'cc': center_cluster_loss.data})

        loss_f_d_sh = Fb_dt(x_sh_pl, labels)
        loss_Fb_im = Fb_dt(x_im_pl, labels)
        fb_loss = loss_Fb_im + loss_f_d_sh
        loss += fb_loss

        metric.update({'f_dt': fb_loss.data})

        feat = self.bn_neck(feat)
        x_im_pl = self.bn_neck_im(x_im_pl)
        x_sh_pl = self.bn_neck_sh(x_sh_pl)
        sub_nb = sub + 0  ##模态标签

        sp_logits = self.D_sp(x_im_pl)
        unad_loss_b = self.id_loss(sp_logits.float(), sub_nb)
        unad_loss = unad_loss_b

        pseu_sh_logits = self.D_share(x_sh_pl)
        p_sub = sub_nb.chunk(2)[0].repeat_interleave(2)
        pp_sub = torch.roll(p_sub, -1)
        pseu_loss = self.id_loss(pseu_sh_logits.float(), pp_sub)
        loss+=unad_loss+pseu_loss

        metric.update({'unad': unad_loss.data})
        metric.update({'pse': pseu_loss.data})
        if self.classification:
            logits_im = self.classifier_im(x_im_pl)                                # 我试一下将原始特征的logits蒸馏到擦除特征的logits上看看
            logits_sh = self.classifier_sh(x_sh_pl)

            cls_im_loss = self.id_loss(logits_im.float(), labels)
            cls_sh_loss = self.id_loss(logits_sh.float(), labels)
            loss = loss + cls_sh_loss + cls_im_loss

            logits = self.classifier(feat)
            cls_loss = self.id_loss(logits.float(), labels)
            loss += cls_loss
            metric.update({'acc': calc_acc(logits.data, labels), 'ce_sh': cls_sh_loss.data,'ce_im':cls_im_loss.data,'ce': cls_loss.data})



        if self.erase:
            n = x_im_pl.size(0)
            input_sh = x_sh_pl.detach()
            input_im = x_im_pl.detach()
            id_im_centers = []
            for i in range(n):
                id_im_centers.append(input_im[labels == labels[i]].mean(0))
            id_im_centers = torch.stack(id_im_centers)
            weight1 = self.sigmoid_1(id_im_centers)

            modality_centers = []
            for i in range(n):
                modality_centers.append(input_im[sub == sub[i]].mean(0))
            weight2 = 1 - self.sigmoid_2(torch.stack(modality_centers))

            id_sh_centers = []
            for i in range(n):
                id_sh_centers.append(input_sh[labels == labels[i]].mean(0))
            id_sh_centers = torch.stack(id_sh_centers)
            weight3 = self.sigmoid_3(id_sh_centers)
            loss_earase = 0.2 * ((weight1 - weight_sp_id).abs().sum(1).mean() / weight1.size(0) + (
                    weight_erase - weight2).abs().sum(1).mean() / weight1.size(0) + (
                                         weight_sh_id - weight3).abs().sum(1).mean() / weight1.size(0))
            loss += loss_earase
            metric.update({'erase': loss_earase.data})

        if self.cml:
            # cam_ids = kwargs.get('cam_ids')
            # sub = (cam_ids == 3) + (cam_ids == 6)
            
            logits_v = self.visible_classifier(feat[sub == 0])
            v_cls_loss = self.id_loss(logits_v.float(), labels[sub == 0])
            loss += v_cls_loss * self.weight_sid
            logits_i = self.infrared_classifier(feat[sub == 1])
            i_cls_loss = self.id_loss(logits_i.float(), labels[sub == 1])
            loss += i_cls_loss * self.weight_sid

            logits_m = torch.cat([logits_v, logits_i], 0).float()
            with torch.no_grad():
                self.infrared_classifier_.weight.data = self.infrared_classifier_.weight.data * (1 - self.update_rate) \
                                                 + self.infrared_classifier.weight.data * self.update_rate
                self.visible_classifier_.weight.data = self.visible_classifier_.weight.data * (1 - self.update_rate) \
                                                 + self.visible_classifier.weight.data * self.update_rate

                logits_v_ = self.infrared_classifier_(feat[sub == 0])
                logits_i_ = self.visible_classifier_(feat[sub == 1])

                logits_m_ = torch.cat([logits_v_, logits_i_], 0).float()
            logits_m = F.softmax(logits_m, 1)
            logits_m_ = F.log_softmax(logits_m_, 1)
            mod_loss = self.KLDivLoss(logits_m_, logits_m) 

            loss += mod_loss * self.weight_KL + (v_cls_loss + i_cls_loss) * self.weight_sid
            metric.update({'ce-v': v_cls_loss.data})
            metric.update({'ce-i': i_cls_loss.data})
            metric.update({'KL': mod_loss.data})

        return loss, metric
