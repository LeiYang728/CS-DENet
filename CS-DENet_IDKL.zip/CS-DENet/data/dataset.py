import os
from glob import glob

import torch
from PIL import Image
from torch.utils.data import Dataset


class SYSUDataset(Dataset):



    def __init__(self, root, mode='train', transform_rgb=None, transform_ir=None, memory_loaded=False):
        assert os.path.isdir(root)
        assert mode in ['train', 'gallery', 'query']

        if mode == 'train':
            train_ids = open(os.path.join(root, 'exp', 'train_id.txt')).readline()
            val_ids = open(os.path.join(root, 'exp', 'val_id.txt')).readline()

            train_ids = train_ids.strip('\n').split(',')
            val_ids = val_ids.strip('\n').split(',')
            selected_ids = train_ids + val_ids
        else:
            test_ids = open(os.path.join(root, 'exp', 'test_id.txt')).readline()
            selected_ids = test_ids.strip('\n').split(',')

        selected_ids = [int(i) for i in selected_ids]
        num_ids = len(selected_ids)

        img_paths = glob(os.path.join(root, '**/*.jpg'), recursive=True)
        img_paths = [path for path in img_paths if int(path.split('\\')[-2]) in selected_ids]

        if mode == 'gallery':
            img_paths = [path for path in img_paths if int(path.split('\\')[-3][-1]) in (1, 2, 4, 5)]
        elif mode == 'query':
            img_paths = [path for path in img_paths if int(path.split('\\')[-3][-1]) in (3, 6)]

        img_paths = sorted(img_paths)
        self.img_paths = img_paths
        self.cam_ids = [int(path.split('\\')[-3][-1]) for path in img_paths]
        self.num_ids = num_ids
        self.transform_rgb = transform_rgb
        self.transform_ir = transform_ir

        if mode == 'train':
            id_map = dict(zip(selected_ids, range(num_ids)))
            self.ids = [id_map[int(path.split('\\')[-2])] for path in img_paths]
        else:
            self.ids = [int(path.split('\\')[-2]) for path in img_paths]

        self.memory_loaded = memory_loaded
        if memory_loaded:
            self.img_data = [Image.open(path) for path in self.img_paths]

    def __len__(self):
        return len(self.img_paths)

    def __getitem__(self, item):
        path = self.img_paths[item]
        if self.memory_loaded:
            img = self.img_data[item]
        else:
            img = Image.open(path)

        label = torch.as_tensor(self.ids[item], dtype=torch.long)
        cam = torch.as_tensor(self.cam_ids[item], dtype=torch.long)
        item = torch.as_tensor(item, dtype=torch.long)

        if cam == 3 or cam == 6:
            if self.transform_ir is not None:
                img = self.transform_ir(img)
        else:
            if self.transform_rgb is not None:
                img = self.transform_rgb(img)

        return img, label, cam, path, item


class RegDBDataset(Dataset):


    def __init__(self, root, mode='train', transform_rgb=None, transform_ir=None, memory_loaded=False):
        assert os.path.isdir(root)
        assert mode in ['train', 'gallery', 'query']

        def loadIdx(index):
            Lines = index.readlines()
            idx = []
            for line in Lines:
                tmp = line.strip('\n')
                tmp = tmp.split(' ')
                idx.append(tmp)
            return idx

        num = '1'
        if mode == 'train':
            index_RGB = loadIdx(open(root + '/idx/train_visible_' + num + '.txt', 'r'))
            index_IR = loadIdx(open(root + '/idx/train_thermal_' + num + '.txt', 'r'))
        else:
            index_RGB = loadIdx(open(root + '/idx/test_visible_' + num + '.txt', 'r'))
            index_IR = loadIdx(open(root + '/idx/test_thermal_' + num + '.txt', 'r'))

        if mode == 'gallery':
            img_paths = [root + '/' + path for path, _ in index_RGB]
        elif mode == 'query':
            img_paths = [root + '/' + path for path, _ in index_IR]
        else:
            img_paths = [root + '/' + path for path, _ in index_RGB] + [root + '/' + path for path, _ in index_IR]

        selected_ids = [int(path.split('/')[-2]) for path in img_paths]
        selected_ids = list(set(selected_ids))
        num_ids = len(selected_ids)

        img_paths = sorted(img_paths)
        self.img_paths = img_paths
        self.cam_ids = [int(path.split('/')[-3] == 'Thermal') + 2 for path in img_paths]
        # Note: In SYSU-MM01 dataset, the visible cams are 1 2 4 5, and thermal cams are 3 6.
        # To simplify the code, visible cam is 2 and thermal cam is 3 in RegDB dataset.
        self.num_ids = num_ids
        self.transform_rgb = transform_rgb
        self.transform_ir = transform_ir

        if mode == 'train':
            id_map = dict(zip(selected_ids, range(num_ids)))
            self.ids = [id_map[int(path.split('/')[-2])] for path in img_paths]
        else:
            self.ids = [int(path.split('/')[-2]) for path in img_paths]

        self.memory_loaded = memory_loaded
        if memory_loaded:
            self.img_data = [Image.open(path) for path in self.img_paths]

    def __len__(self):
        return len(self.img_paths)

    def __getitem__(self, item):
        if self.memory_loaded:
            img = self.img_data[item]
        else:
            path = self.img_paths[item]
            img = Image.open(path)

        label = torch.tensor(self.ids[item], dtype=torch.long)
        cam = torch.tensor(self.cam_ids[item], dtype=torch.long)
        item = torch.tensor(item, dtype=torch.long)

        if cam == 3 or cam == 6:
            if self.transform_ir is not None:
                img = self.transform_ir(img)
        else:
            if self.transform_rgb is not None:
                img = self.transform_rgb(img)

        return img, label, cam, path, item

class LLCMData(Dataset):
    def __init__(self, root, mode='train', transform_rgb=None, transform_ir=None, memory_loaded=False):
        # Load training images (path) and labels
        assert os.path.isdir(root)
        assert mode in ['train', 'gallery', 'query']

        def loadIdx(index):
            Lines = index.readlines()
            idx = []
            for line in Lines:
                tmp = line.strip('\n')
                tmp = tmp.split(' ')
                idx.append(tmp)
            return idx

        if mode == 'train':
            index_RGB = loadIdx(open(root + '/idx/train_vis.txt','r'))
            index_IR  = loadIdx(open(root + '/idx/train_nir.txt','r'))
        else:
            index_RGB = loadIdx(open(root + '/idx/test_vis.txt','r'))
            index_IR  = loadIdx(open(root + '/idx/test_nir.txt','r'))


        if mode == 'gallery':
            img_paths = [root + '/' + path for path, _ in index_RGB]
        elif mode == 'query':
            img_paths = [root + '/' + path for path, _ in index_IR]
        else:
            img_paths = [root + '/' + path for path, _ in index_RGB] + [root + '/' + path for path, _ in index_IR]

        selected_ids = [int(path.split('/')[-2]) for path in img_paths]
        selected_ids = list(set(selected_ids))
        num_ids = len(selected_ids)
        # path = '/home/zhang/E/RKJ/MAPnet/dataset/LLCM/nir/0351/0351_c06_s200656_f4830_nir.jpg'
        # img = Image.open(path).convert('RGB')
        # img = np.array(img, dtype=np.uint8)
        # import pdb
        # pdb.set_trace()

        img_paths = sorted(img_paths)
        self.img_paths = img_paths
        self.cam_ids = [int(path.split('/')[-3] == 'nir') + 2 for path in img_paths]
        self.num_ids = num_ids
        self.transform_rgb = transform_rgb
        self.transform_ir = transform_ir

        if mode == 'train':
            id_map = dict(zip(selected_ids, range(num_ids)))

            self.ids = [id_map[int(path.split('/')[-2])] for path in img_paths]
        else:
            self.ids = [int(path.split('/')[-2]) for path in img_paths]

        self.memory_loaded = memory_loaded
        if memory_loaded:
            self.img_data = [Image.open(path) for path in self.img_paths]

    def __len__(self):
        return len(self.img_paths)

    def __getitem__(self, item):
        if self.memory_loaded:
            img = self.img_data[item]
        else:
            path = self.img_paths[item]
            img = Image.open(path)

        label = torch.tensor(self.ids[item], dtype=torch.long)
        cam = torch.tensor(self.cam_ids[item], dtype=torch.long)
        item = torch.tensor(item, dtype=torch.long)

        if cam == 3 or cam == 6:
            if self.transform_ir is not None:
                img = self.transform_ir(img)
        else:
            if self.transform_rgb is not None:
                img = self.transform_rgb(img)

        return img, label, cam, path, item