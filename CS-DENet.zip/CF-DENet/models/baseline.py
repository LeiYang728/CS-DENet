import math
import torch
import torch.nn as nn
from torch.nn import init
from torch.nn import functional as F
from torch.nn import Parameter
import numpy as np
from layers.loss.tcl import tcl_Loss
import cv2
from layers.module.reverse_grad import ReverseGrad
from models.resnet import resnet50, embed_net ,Discrimination
from models.Orthogonality_regulization import OFPenalty
from utils.calc_acc import calc_acc

from layers import TripletLoss, RerankLoss
from layers import CenterTripletLoss
from layers import CenterLoss
from layers import cbam
from layers import NonLocalBlockND
from utils.rerank import re_ranking, pairwise_distance



def Fb_dt(feat, labels):
    feat_dt = feat
    n_ft = feat_dt.size(0)
    dist_f = torch.pow(feat_dt, 2).sum(dim=1, keepdim=True).expand(n_ft, n_ft)
    dist_f = dist_f + dist_f.t()
    dist_f.addmm_(1, -2, feat_dt, feat_dt.t())
    dist_f = dist_f.clamp(min=1e-12).sqrt()
    mask_ft = labels.expand(n_ft, n_ft).eq(labels.expand(n_ft, n_ft).t())
    mask_ft_1 = torch.ones(n_ft, n_ft, dtype=bool)
    for i in range(n_ft):
        mask_ft_1[i, i] = 0
    mask_ft_2 = []
    for i in range(n_ft):

        mask_ft_2.append(mask_ft[i][mask_ft_1[i]])
    mask_ft_2 = torch.stack(mask_ft_2)
    dist_f_2 = []
    for i in range(n_ft):

        dist_f_2.append(dist_f[i][mask_ft_1[i]])
    dist_f_2 = torch.stack(dist_f_2)
    dist_f_2 = F.softmax(-(dist_f_2 - 1), 1)
    cN_ft = (mask_ft_2[0] == True).sum()
    f_d_ap = []
    for i in range(n_ft):

        f_d_ap.append(dist_f_2[i][mask_ft_2[i]])
    f_d_ap = torch.stack(f_d_ap).flatten()
    loss_f_d_ap = []
    xs_ft = 1
    m_ft = f_d_ap.size(0)
    for i in range(m_ft):
        loss_f_d_ap.append(
            -xs_ft * (1 / cN_ft) * torch.log(xs_ft * cN_ft * f_d_ap[i]))
    loss_f_d_ap = torch.stack(loss_f_d_ap).clamp(max=1e+3).sum() / n_ft
    return loss_f_d_ap


def gem(x, p=3, eps=1e-6):
    return F.avg_pool2d(x.clamp(min=eps).pow(p), (x.size(-2), x.size(-1))).pow(1. / p)

def gem_p(x):
    ss = gem(x).squeeze()  # Gem池化
    ss= ss.view(ss.size(0), -1)  # Gem池化
    return ss
def pairwise_dist(x, y):
    # Compute pairwise distance of vectors
    xx = (x**2).sum(dim=1, keepdim=True)
    yy = (y**2).sum(dim=1, keepdim=True).t()
    dist = xx + yy - 2.0 * torch.mm(x, y.t())
    dist = dist.clamp(min=1e-6).sqrt()  # for numerical stability
    return dist

def kl_soft_dist(feat1,feat2):
    n_st = feat1.size(0)
    dist_st = pairwise_dist(feat1, feat2)
    mask_st_1 = torch.ones(n_st, n_st, dtype=bool)
    for i in range(n_st):  # 将同一类样本中自己与自己的距离舍弃
        mask_st_1[i, i] = 0
    dist_st_2 = []
    for i in range(n_st):
        dist_st_2.append(dist_st[i][mask_st_1[i]])
    dist_st_2 = torch.stack(dist_st_2)
    return dist_st_2


def Bg_kl(logits1, logits2):####输入:(60,206),(60,206)
    KL = nn.KLDivLoss(reduction='batchmean')
    kl_loss_12 = KL(F.log_softmax(logits1, 1), F.softmax(logits2, 1))
    kl_loss_21 = KL(F.log_softmax(logits2, 1), F.softmax(logits1, 1))
    bg_loss_kl = kl_loss_12 + kl_loss_21
    return kl_loss_12, bg_loss_kl
def Sm_kl(logits1, logits2, labels):
    KL = nn.KLDivLoss(reduction='batchmean')
    m_kl = torch.div((labels == labels[0]).sum(), 2, rounding_mode='floor')
    v_logits_s = logits1.split(m_kl, 0)
    i_logits_s = logits2.split(m_kl, 0)
    sm_v_logits = torch.cat(v_logits_s, 1)  # .t()  # 5,206*12->206*12,5
    sm_i_logits = torch.cat(i_logits_s, 1)  # .t()
    sm_kl_loss_vi = KL(F.log_softmax(sm_v_logits, 1), F.softmax(sm_i_logits, 1))
    sm_kl_loss_iv = KL(F.log_softmax(sm_i_logits, 1), F.softmax(sm_v_logits, 1))
    sm_kl_loss = sm_kl_loss_vi + sm_kl_loss_iv
    return sm_kl_loss_vi, sm_kl_loss



class Baseline(nn.Module):
    def __init__(self, num_classes=None, drop_last_stride=False, decompose=False, **kwargs):
        super(Baseline, self).__init__()

        self.drop_last_stride = drop_last_stride
        self.decompose = decompose


        self.base_dim = 2048
        self.dim = 0
        self.part_num = kwargs.get('num_parts', 0)
        self.mutual_learning = kwargs.get('mutual_learning', False)

        print("output feat length:{}".format(self.base_dim + self.dim * self.part_num))
        self.bn_neck = nn.BatchNorm1d(self.base_dim + self.dim * self.part_num)
        nn.init.constant_(self.bn_neck.bias, 0)
        self.bn_neck.bias.requires_grad_(False)

        self.bn_neck_sh = nn.BatchNorm1d(self.base_dim + self.dim * self.part_num)
        nn.init.constant_(self.bn_neck_sh.bias, 0)
        self.bn_neck_sh.bias.requires_grad_(False)

        self.bn_neck_im = nn.BatchNorm1d(self.base_dim + self.dim * self.part_num)
        nn.init.constant_(self.bn_neck_im.bias, 0)
        self.bn_neck_im.bias.requires_grad_(False)

        if kwargs.get('eval', False):
            return
        self.fusion = kwargs.get('fusion', False)
        self.sp_de = kwargs.get('sp_de', False)
        self.erase = kwargs.get('erase', False)
        self.classification = kwargs.get('classification', False)
        self.triplet = kwargs.get('triplet', False)
        self.center_cluster = kwargs.get('center_cluster', False)
        self.center_loss = kwargs.get('center', False)
        self.margin = kwargs.get('margin', 0.3)
        self.CSA1 = kwargs.get('bg_kl', False)
        self.CSA2 = kwargs.get('sm_kl', False)
        self.TGSA = kwargs.get('distalign', False)
        self.IP = kwargs.get('IP', False)
        self.fb_dt = kwargs.get('fb_dt', False)
        self.tcl_loss = tcl_Loss()
        kk =4
        self.backbone = embed_net(drop_last_stride=drop_last_stride, decompose=decompose,fusion=self.fusion)
        if self.decompose:
            self.classifier_fuse = nn.Linear(self.base_dim + self.dim * self.part_num, num_classes, bias=False)
            self.classifier_sh = nn.Linear(self.base_dim, num_classes, bias=False)
            self.classifier_im = nn.Linear(self.base_dim, num_classes, bias=False)
            self.D_share = Discrimination(2048)
            self.D_sp = Discrimination(2048)

        else:
            self.classifier_fuse = nn.Linear(self.base_dim + self.dim * self.part_num, num_classes, bias=False)
        if self.classification:
            self.id_loss = nn.CrossEntropyLoss(ignore_index=-1)
        if self.triplet:
            self.triplet_loss = TripletLoss(margin=self.margin)
            self.rerank_loss = RerankLoss(margin=0.7)
        if self.center_cluster:
            k_size = kwargs.get('k_size', 8)
            self.center_cluster_loss = CenterTripletLoss(k_size=k_size, margin=self.margin)
        if self.center_loss:
            self.center_loss = CenterLoss(num_classes, self.base_dim + self.dim * self.part_num)
        self.beta = 1e-1
        self.orth_loss = OFPenalty(self.beta)
        self.sp_weight = nn.Sequential(
            nn.Linear(2048,128,bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(128,2048,bias=False),
            nn.Sigmoid()
        )
        self.sigmoid = nn.Sigmoid()
        self.sigmoid_1 = nn.Sigmoid()
        self.sigmoid_2 = nn.Sigmoid()
        self.sigmoid_3 = nn.Sigmoid()
    def forward(self, inputs, labels=None, **kwargs):

        cam_ids = kwargs.get('cam_ids')
        sub = (cam_ids == 3) + (cam_ids == 6)
        sun_bn = sub + 0
        #epoch = kwargs.get('epoch')
        # CNN

        x_fuse, fuse_pl, x_sh, x_sh_pl, x_im,x_im_pl, weight_earase = self.backbone(inputs)

        feats = fuse_pl

        if not self.training:
            if feats.size(0) == 2048:
                feats = self.bn_neck(feats.permute(1, 0))
                logits = self.classifier_fuse(feats)
                return logits  # feats #

                '''
                feats = self.bn_neck(feats.permute(1, 0))
                logits = self.classifier_fuse(feats)
                return logits  # feats #
                '''
            else:
                feats = self.bn_neck(
                    feats)
                return feats

        else:
            return self.train_forward(feats, labels,
                                      sub, x_sh, x_sh_pl, x_im, x_im_pl, weight_earase=weight_earase, **kwargs)





    def train_forward(self, feat, labels,
                       sub, x_sh,x_sh_pl,x_im,x_im_pl,weight_earase=None,**kwargs):
        epoch = kwargs.get('epoch')
        metric = {}
        loss = 0
        if self.sp_de:
            feat_orth = [x_sh, x_im]
            orth_loss  = self.orth_loss(feat_orth)
            loss += orth_loss
            metric.update({'orth1': orth_loss.data })
        if self.center_cluster:
            targets = torch.cat((labels[sub==0],labels[sub==0]),0)
            x_spv,x_shv,x_spi,x_shi = x_im_pl[sub == 0],x_sh_pl[sub == 0],x_im_pl[sub == 1],x_sh_pl[sub == 1]
            inputs_v = torch.cat((x_spv,x_shv),dim=0)
            inputs_i = torch.cat((x_spi,x_shi),dim=0)
            loss_tcl = self.tcl_loss(inputs_v,inputs_v,targets) + self.tcl_loss(inputs_i,inputs_i,targets)
            loss+=loss_tcl
            metric.update({'tcl':loss_tcl.data})
        if self.triplet:
        #if False:
            triplet_loss_fuse, dist, fuse_ap, fuse_an = self.triplet_loss(feat.float(), labels)
            triplet_loss_sh , dist , sh_ap , sh_an = self.triplet_loss(x_sh_pl.float(),labels)
            triplet_loss_e, _, sp_ap, sp_an = self.triplet_loss(x_im_pl.float(), labels)
            trip_loss = triplet_loss_fuse + triplet_loss_e + triplet_loss_sh
            loss += trip_loss
            metric.update({'tri': trip_loss.data})


        bb = 120  #90
        if self.TGSA:           #这两个都是将特有特征的分布蒸馏到共享特征的分布上

            sf_e_dist_v = kl_soft_dist(x_im_pl[sub == 0], x_im_pl[sub == 0])
            sf_e_dist_i = kl_soft_dist(x_im_pl[sub == 1], x_im_pl[sub == 1])
            sf_sh_dist_v = kl_soft_dist(x_sh_pl[sub == 0], x_sh_pl[sub == 0])
            sf_sh_dist_i = kl_soft_dist(x_sh_pl[sub == 1], x_sh_pl[sub == 1])
            half_B0 = x_im_pl[sub == 0].shape[0] // 2
            feat_e_half0 = x_im_pl[sub == 0][:half_B0]
            half_B1 = x_im_pl[sub == 1].shape[0] // 2
            feat_e_half1 = x_im_pl[sub == 1][:half_B1]
            feat_cross = torch.cat((feat_e_half0, feat_e_half1), dim=0)
            sf_e_dist_vi = kl_soft_dist(feat_cross, feat_cross)



            _, kl_inter_v = Bg_kl(sf_e_dist_v, sf_sh_dist_v)
            _, kl_inter_i = Bg_kl(sf_e_dist_i, sf_sh_dist_i)


            _, kl_intra1 = Bg_kl(sf_e_dist_v, sf_e_dist_i)
            _, kl_intra2 = Bg_kl(sf_e_dist_v, sf_e_dist_vi)
            _, kl_intra3 = Bg_kl(sf_e_dist_vi, sf_e_dist_i)

            kl_intra = kl_intra1 + kl_intra2 + kl_intra3



            if feat.size(0) == bb:
                soft_dt = kl_intra + (kl_inter_v + kl_inter_i) * 0.6


            else:
                soft_dt = (kl_intra1 + kl_inter_v + kl_inter_i) * 0.1

            loss += soft_dt
            metric.update({'soft_dt': soft_dt.data})

        if self.center_loss:
            center_loss = self.center_loss(feat.float(), labels)
            loss += center_loss
            metric.update({'cen': center_loss.data})

        if self.fb_dt:
            loss_f_d_ap = Fb_dt(feat, labels)
            loss_f_d_sh = Fb_dt(x_sh_pl,labels)
            loss_Fb_im = Fb_dt(x_im_pl, labels)
            fb_loss = loss_f_d_ap + loss_Fb_im + loss_f_d_sh
            loss += fb_loss

            metric.update({'f_dt': fb_loss.data})

        feat = self.bn_neck(feat)
        x_im_pl = self.bn_neck_im(x_im_pl)
        x_sh_pl = self.bn_neck_sh(x_sh_pl)

        sub_nb = sub + 0  ##模态标签

        if self.IP:
            ################
            ################
            x=1

            ################
            ################

        if self.decompose:


            logits_fuse = self.classifier_fuse(feat)  # self.bn_neck_un(sp_pl)
            loss_id_fuse = self.id_loss(logits_fuse.float(), labels)            # 这就是ID损失啊，但是只有特有特征的 ID损失

            sp_logits = self.D_sp(x_im_pl)
            unad_loss_b = self.id_loss(sp_logits.float(), sub_nb)
            unad_loss = unad_loss_b

            pseu_sh_logits = self.D_share(x_sh_pl)
            p_sub = sub_nb.chunk(2)[0].repeat_interleave(2)
            pp_sub = torch.roll(p_sub, -1)
            pseu_loss = self.id_loss(pseu_sh_logits.float(), pp_sub)

            loss+=loss_id_fuse + pseu_loss + unad_loss
            metric.update({'unad': unad_loss.data})
            metric.update({'id_fuse':loss_id_fuse.data})
            metric.update({'pse': pseu_loss.data})

        if self.classification:
            logits_im = self.classifier_im(x_im_pl)                                # 我试一下将原始特征的logits蒸馏到擦除特征的logits上看看
            logits_sh = self.classifier_sh(x_sh_pl)
            if self.CSA1:

                _, inter_bg_v = Bg_kl(logits_im[sub == 0], logits_sh[sub == 0])
                _, inter_bg_i = Bg_kl(logits_im[sub == 1], logits_sh[sub == 1])

                _, intra_bg = Bg_kl(logits_sh[sub == 0], logits_sh[sub == 1])


                if feat.size(0) == bb:
                    bg_loss = intra_bg + (inter_bg_v + inter_bg_i) * 0.8  # intra_bg + (inter_bg_v + inter_bg_i) * 0.7

                else:
                    bg_loss = intra_bg + (inter_bg_v + inter_bg_i) * 0.3
                loss += bg_loss
                metric.update({'bg_kl': bg_loss.data})

            if self.CSA2:
                _, inter_Sm_v = Sm_kl(logits_im[sub == 0], logits_sh[sub == 0], labels)
                _, inter_Sm_i = Sm_kl(logits_im[sub == 1], logits_sh[sub == 1], labels)
                inter_Sm = inter_Sm_v + inter_Sm_i
                _, intra_Sm= Sm_kl(logits_sh[sub == 0], logits_sh[sub == 1], labels)

                if feat.size(0) == bb:
                    sm_kl_loss = intra_Sm + inter_Sm * 0.8

                else:
                    sm_kl_loss = intra_Sm + inter_Sm * 0.3
                loss += sm_kl_loss
                metric.update({'sm_kl': sm_kl_loss.data})
            cls_im_loss = self.id_loss(logits_im.float(), labels)
            cls_sh_loss = self.id_loss(logits_sh.float(),labels)
            loss = loss + cls_sh_loss + cls_im_loss

            metric.update({'acc': calc_acc(logits_fuse.data, labels), 'ce_sh': cls_sh_loss.data,'ce_im':cls_im_loss.data})

            if self.erase:
                inputs = x_im_pl.detach()
                n = inputs.size(0)
                id_centers = []
                for i in range(n):
                    id_centers.append(inputs[labels == labels[i]].mean(0))
                id_centers = torch.stack(id_centers)

                modality_centers = []
                for i in range(n):
                    modality_centers.append(inputs[sub == sub[i]].mean(0))
                modality_centers =1 - self.sigmoid(torch.stack(modality_centers))

                weight_select = torch.zeros_like(modality_centers)
                threshold = 0.05
                weight_select += modality_centers >= threshold + 0
                weight_sp = self.sp_weight(id_centers * weight_select)
                _, KL1 = Sm_kl(weight_earase, weight_sp, labels)
                _, KL2 = Bg_kl(weight_earase, weight_sp)
                loss_earase = KL1 + KL2
                loss += loss_earase
                metric.update({'earase': loss_earase.data})

        return loss, metric
